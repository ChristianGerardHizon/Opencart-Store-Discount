<?php
$_['heading_title']             = 'Store Discount';

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: You have modified store wide discount';


// Table headers
$_['entry_customer_group']      = 'Customer';
$_['entry_quantity']            = 'Quantity';
$_['entry_priority']            = 'Priority';
$_['entry_price']               = 'Price';
$_['entry_date_start']          = 'Date Start';
$_['entry_date_end']            = 'Date End';